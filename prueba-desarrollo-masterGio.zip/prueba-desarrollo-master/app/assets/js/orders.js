$(function() {
    $('.btn-submit').trigger('click');
});