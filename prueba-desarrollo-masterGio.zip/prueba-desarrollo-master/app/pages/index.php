<?php 
header("Location: orders.php");