<?php 
header("Location: pages/");
